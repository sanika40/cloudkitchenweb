import { Component } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { OrderDetailsService } from 'src/app/services/order-details.service';

@Component({
  selector: 'app-update-product',
  templateUrl: './update-product.component.html',
  styleUrls: ['./update-product.component.css']
})
export class UpdateProductComponent {
  constructor(private serv: OrderDetailsService,private actvRoute:ActivatedRoute){}


  prodId:any
  prodDetails:any
  ngOnInit(){
    this.actvRoute.params.subscribe((pid)=>{
      this.prodId = pid["id"]
      console.log("Product Id is", this.prodId)

    })

    this.serv.SearchProduct(this.prodId).subscribe((data)=>{
      this.prodDetails=data
      console.log(this.prodDetails)
    })
  }








}
